//
//  ViewController.swift
//  Task2
//
//  Created by sravan yadav on 22/05/24.
//
import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    var affiliates: [Affiliate] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        
        tableView.dataSource = self
        tableView.delegate = self
        
        fetchData()
    }
    
    func fetchData() {
        let urlString = "https://therundown-therundown-v1.p.rapidapi.com/affiliates"
        guard let url = URL(string: urlString) else {
            print("Error: Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("24376ae05bmsh4bc49372f92fa0dp144bf3jsncdd87641d2b1", forHTTPHeaderField: "x-rapidapi-key")
        request.setValue("therundown-therundown-v1.p.rapidapi.com", forHTTPHeaderField: "x-rapidapi-host")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { (data, response, error) in
            guard let data = data, error == nil else {
                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: [])
                print(json)
            } catch {
                print("Error: Unable to parse JSON data - \(error.localizedDescription)")
            }

           
        }
        
        task.resume()
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return affiliates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        let affiliate = affiliates[indexPath.row]
        cell.nameLabel.text = affiliate.name
        cell.websiteLabel.text = affiliate.website
        return cell
    }
    
  
}
