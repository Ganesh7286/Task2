//
//  DataModel.swift
//  Task2
//
//  Created by sravan yadav on 22/05/24.
//

import Foundation


struct Affiliate {
    let name: String
    let website: String
   
}
